import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { z } from 'zod';
import { SESSION_COOKIE, verifySession } from '@/lib/auth';
import { getSettings, setSettings } from '@/lib/repo';

const SettingsInput = z.object({
  siteName: z.string().optional(),
  tagline: z.string().optional(),
  heroImageUrl: z.string().url().optional().or(z.literal('')),
  heroHeadline: z.string().optional(),
  geminiApiKey: z.string().optional(),
  geminiModel: z.string().optional(),
  instagram: z.string().optional(),
  kmWalked: z.string().optional(),
});

export async function GET() {
  if (!(await verifySession(cookies().get(SESSION_COOKIE)?.value)))
    return NextResponse.json({ error: { message: 'Não autenticado' } }, { status: 401 });
  const s = await getSettings();
  if (s.geminiApiKey) s.geminiApiKey = '••••••••' + s.geminiApiKey.slice(-4); // não devolve o segredo
  return NextResponse.json({ data: s });
}

export async function POST(req: Request) {
  if (!(await verifySession(cookies().get(SESSION_COOKIE)?.value)))
    return NextResponse.json({ error: { message: 'Não autenticado' } }, { status: 401 });

  const ct = req.headers.get('content-type') ?? '';
  const raw = ct.includes('application/json')
    ? await req.json()
    : Object.fromEntries((await req.formData()).entries());

  const parsed = SettingsInput.safeParse(raw);
  if (!parsed.success)
    return NextResponse.json({ error: { message: 'Validação falhou', issues: parsed.error.flatten() } }, { status: 400 });

  const entries: Record<string, string> = {};
  for (const [k, val] of Object.entries(parsed.data)) {
    if (val === undefined || val === '') continue;
    if (k === 'geminiApiKey' && String(val).startsWith('••••')) continue; // não sobrescreve com o mascarado
    entries[k] = String(val);
  }
  await setSettings(entries);

  const accept = req.headers.get('accept') ?? '';
  if (!accept.includes('application/json')) {
    return NextResponse.redirect(new URL('/admin/configuracoes?saved=1', req.url), 303);
  }
  return NextResponse.json({ ok: true });
}
