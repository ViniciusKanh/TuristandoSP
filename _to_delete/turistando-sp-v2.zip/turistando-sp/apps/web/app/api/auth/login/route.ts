import { NextResponse } from 'next/server';
import { checkPassword, createSession, SESSION_COOKIE } from '@/lib/auth';

export async function POST(req: Request) {
  const form = await req.formData();
  const password = String(form.get('password') ?? '');
  const raw = String(form.get('next') || '/admin');
  const next = raw.startsWith('/') ? raw : '/admin';

  if (!checkPassword(password)) {
    const url = new URL('/admin/login', req.url);
    url.searchParams.set('error', '1');
    url.searchParams.set('next', next);
    return NextResponse.redirect(url, 303);
  }

  const res = NextResponse.redirect(new URL(next, req.url), 303);
  res.cookies.set(SESSION_COOKIE, await createSession(), {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 24 * 30,
  });
  return res;
}
