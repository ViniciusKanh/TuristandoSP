import { NextResponse } from 'next/server';
import { z } from 'zod';
import { slugify, type Place } from '@turistando/core';
import { SESSION_COOKIE, verifySession } from '@/lib/auth';
import { getAllPlaces, insertPlace, slugExists } from '@/lib/repo';
import { cookies } from 'next/headers';

const PlaceInput = z.object({
  name: z.string().min(2),
  shortDescription: z.string().min(4),
  description: z.string().default(''),
  neighborhood: z.string().min(1),
  region: z.enum(['centro', 'zona-norte', 'zona-sul', 'zona-leste', 'zona-oeste']),
  lat: z.coerce.number().min(-24.1).max(-23.3), // limites da cidade de São Paulo
  lng: z.coerce.number().min(-46.9).max(-46.3),
  categories: z.array(z.string()).default([]),
  tags: z.array(z.string()).default([]),
  priceMin: z.coerce.number().min(0).default(0),
  priceMax: z.coerce.number().min(0).default(0),
  free: z.coerce.boolean().default(false),
  website: z.string().url().optional().or(z.literal('')),
  instagram: z.string().optional(),
  hours: z.string().optional(),
  recommendedMinutes: z.coerce.number().int().positive().optional(),
  favorite: z.coerce.boolean().default(false),
  wantToReturn: z.coerce.boolean().default(false),
  coverImageUrl: z.string().url().optional().or(z.literal('')),
});

export async function GET() {
  return NextResponse.json({ data: await getAllPlaces() });
}

export async function POST(req: Request) {
  if (!(await verifySession(cookies().get(SESSION_COOKIE)?.value))) {
    return NextResponse.json({ error: { message: 'Não autenticado' } }, { status: 401 });
  }
  let body: unknown;
  try {
    const ct = req.headers.get('content-type') ?? '';
    if (ct.includes('application/json')) body = await req.json();
    else body = Object.fromEntries((await req.formData()).entries());
  } catch {
    return NextResponse.json({ error: { message: 'Corpo inválido' } }, { status: 400 });
  }

  // normaliza checkboxes de formulário ("on") e listas separadas por vírgula
  if (body && typeof body === 'object') {
    const b = body as Record<string, unknown>;
    for (const k of ['free', 'favorite', 'wantToReturn']) if (b[k] === 'on') b[k] = true;
    for (const k of ['categories', 'tags']) if (typeof b[k] === 'string') b[k] = (b[k] as string).split(',').map((s) => s.trim()).filter(Boolean);
  }

  const parsed = PlaceInput.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: { message: 'Validação falhou', issues: parsed.error.flatten() } }, { status: 400 });
  }
  const v = parsed.data;
  let slug = slugify(v.name);
  let i = 2;
  while (await slugExists(slug)) slug = `${slugify(v.name)}-${i++}`;

  const now = new Date().toISOString();
  const place: Place = {
    id: `p-${slug}`,
    slug,
    name: v.name,
    shortDescription: v.shortDescription,
    description: v.description || v.shortDescription,
    address: { street: '' },
    neighborhood: v.neighborhood,
    region: v.region,
    geo: { lat: v.lat, lng: v.lng },
    nearestStations: [],
    categories: v.categories,
    tags: v.tags,
    website: v.website || undefined,
    instagram: v.instagram || undefined,
    price: { min: v.priceMin, max: v.free ? 0 : v.priceMax, free: v.free },
    hours: v.hours ? { summary: v.hours } : undefined,
    accessibility: { wheelchair: false },
    status: 'ativo',
    coverImage: {
      id: `img-${slug}`,
      url: v.coverImageUrl || '',
      demo: !v.coverImageUrl,
      width: 1600,
      height: 1067,
      alt: v.name,
      order: 0,
    },
    favorite: v.favorite,
    wantToReturn: v.wantToReturn,
    recommendedMinutes: v.recommendedMinutes,
    createdAt: now,
    updatedAt: now,
  };
  await insertPlace(place);
  return NextResponse.json({ data: place }, { status: 201 });
}
