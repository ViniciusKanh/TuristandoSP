import type { Metadata } from 'next';
import { getSettings } from '@/lib/repo';
import { tursoConfigured } from '@/lib/db';
import { siteConfig } from '@turistando/core';
import { UrbanLabel } from '@/components/brand';
import { TestConnection } from '@/components/feature/TestConnection';

export const metadata: Metadata = { title: 'Configurações', robots: { index: false } };
export const dynamic = 'force-dynamic';

export default async function ConfiguracoesPage({ searchParams }: { searchParams: { saved?: string } }) {
  const s = await getSettings();
  const geminiSet = Boolean(s.geminiApiKey);

  return (
    <div className="section container container-wide" style={{ maxWidth: '920px' }}>
      <UrbanLabel>Painel · Integrações e identidade</UrbanLabel>
      <h1 className="display title-lg" style={{ marginTop: '0.6rem' }}>Configurações</h1>
      {searchParams.saved ? (
        <p className="mono" style={{ color: 'var(--green)', marginTop: '0.75rem' }}>✓ Salvo.</p>
      ) : null}

      {/* IDENTIDADE */}
      <Card title="Identidade do site" desc="O nome ainda é provisório — troque aqui e vale no site inteiro.">
        <form action="/api/settings" method="post" className="stack">
          <Field label="Nome do site"><input className="input" name="siteName" defaultValue={s.siteName ?? siteConfig.siteName} /></Field>
          <Field label="Tagline"><input className="input" name="tagline" defaultValue={s.tagline ?? siteConfig.tagline} /></Field>
          <Field label="Manchete da Home"><input className="input" name="heroHeadline" defaultValue={s.heroHeadline ?? 'São Paulo é grande demais para conhecer de uma vez.'} /></Field>
          <Field label="Instagram"><input className="input" name="instagram" defaultValue={s.instagram ?? ''} placeholder="@turistandosp" /></Field>
          <button className="btn btn-sm" type="submit">Salvar identidade</button>
        </form>
      </Card>

      {/* IMAGEM DE FUNDO */}
      <Card title="Imagem de fundo (Home)" desc="Cole a URL de uma foto sua para o fundo do topo da Home. Sem imagem, usamos um fundo tipográfico limpo (nada de placeholder poluído).">
        <form action="/api/settings" method="post" className="stack">
          <Field label="URL da imagem de fundo">
            <input className="input" name="heroImageUrl" defaultValue={s.heroImageUrl ?? ''} placeholder="https://… (Vercel Blob, Unsplash, etc.)" />
          </Field>
          <button className="btn btn-sm" type="submit">Salvar imagem</button>
        </form>
        {s.heroImageUrl ? (
          <div className="photo" style={{ aspectRatio: '16/6', marginTop: '1rem' }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={s.heroImageUrl} alt="Prévia do fundo" />
          </div>
        ) : null}
      </Card>

      {/* TURSO */}
      <Card title="Banco de dados — Turso" desc="As credenciais do banco ficam em variáveis de ambiente (nunca no banco). Sem elas, o site usa um arquivo local automaticamente.">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
          <span className="tag" style={{ borderColor: tursoConfigured ? 'var(--green)' : 'var(--border-strong)', color: tursoConfigured ? 'var(--green)' : 'var(--text-faint)' }}>
            {tursoConfigured ? 'Turso conectado' : 'Banco local (arquivo)'}
          </span>
        </div>
        <p className="muted" style={{ fontSize: '0.92rem' }}>No seu <code className="mono">.env.local</code> (e nas variáveis da Vercel):</p>
        <pre className="codeblock">{`TURSO_DATABASE_URL=libsql://seu-banco.turso.io
TURSO_AUTH_TOKEN=eyJ...`}</pre>
        <p className="muted" style={{ fontSize: '0.85rem' }}>
          Crie com a CLI: <code className="mono">turso db create turistando-sp</code> → <code className="mono">turso db show --url</code> e <code className="mono">turso db tokens create</code>. Depois reinicie o servidor.
        </p>
        <TestConnection target="turso" label="Testar conexão do banco" />
      </Card>

      {/* GEMINI */}
      <Card title="Google Gemini" desc="A chave organiza texto e fotos ao publicar (blocos, ordem, limpeza) e fica guardada no servidor.">
        <form action="/api/settings" method="post" className="stack">
          <Field label="API Key do Gemini">
            <input className="input" name="geminiApiKey" type="password" placeholder={geminiSet ? '•••••••• (salva — deixe em branco para manter)' : 'AIza…'} />
          </Field>
          <Field label="Modelo"><input className="input" name="geminiModel" defaultValue={s.geminiModel ?? 'gemini-1.5-flash'} /></Field>
          <button className="btn btn-sm" type="submit">Salvar chave</button>
        </form>
        <TestConnection target="gemini" label="Testar chave do Gemini" />
        <p className="muted" style={{ fontSize: '0.82rem', marginTop: '0.75rem' }}>Salve a chave e depois teste. Pegue a chave em aistudio.google.com/apikey.</p>
      </Card>
    </div>
  );
}

function Card({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <section style={{ border: '1px solid var(--border)', background: 'var(--surface)', padding: 'clamp(1.25rem, 3vw, 2rem)', marginTop: '1.5rem' }}>
      <h2 className="heading h3" style={{ fontSize: '1.25rem' }}>{title}</h2>
      <p className="muted" style={{ fontSize: '0.92rem', margin: '0.4rem 0 1.25rem', maxWidth: '60ch' }}>{desc}</p>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="field">
      <span className="field__label">{label}</span>
      {children}
    </label>
  );
}
