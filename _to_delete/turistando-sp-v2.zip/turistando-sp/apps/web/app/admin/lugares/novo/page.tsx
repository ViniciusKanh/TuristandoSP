import type { Metadata } from 'next';
import { UrbanLabel } from '@/components/brand';
import { NovoLugarForm } from '@/components/feature/NovoLugarForm';

export const metadata: Metadata = { title: 'Novo lugar', robots: { index: false } };
export const dynamic = 'force-dynamic';

export default function NovoLugarPage() {
  return (
    <div className="section container container-wide">
      <UrbanLabel>Cadastro · lugar permanente</UrbanLabel>
      <h1 className="display title-lg" style={{ marginTop: '0.6rem' }}>Cadastrar um lugar</h1>
      <p className="lead" style={{ marginTop: '0.75rem', marginBottom: '2rem' }}>
        O lugar é permanente (existe independente das visitas). Marque a coordenada no mapa — ela vira um ponto no seu mapa de São Paulo na hora.
      </p>
      <NovoLugarForm />
    </div>
  );
}
