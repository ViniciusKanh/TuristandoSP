import 'server-only';
import {
  haversineKm,
  neighborhoodBySlug,
  type Place,
  type Exploration,
  type SiteStats,
  type Category,
  type Neighborhood,
} from '@turistando/core';
import { categories as allCategories } from '@turistando/core';
import { neighborhoods as allNeighborhoods } from '@turistando/core';
import { db, ensureDb } from './db';

async function rows<T = unknown>(sql: string, args: unknown[] = []): Promise<T[]> {
  await ensureDb();
  const res = await db().execute({ sql, args: args as never });
  return res.rows as unknown as T[];
}

function parsePlace(row: { data: string }): Place {
  return JSON.parse(row.data) as Place;
}
function parseExp(row: { data: string }): Exploration {
  return JSON.parse(row.data) as Exploration;
}

export async function getAllPlaces(): Promise<Place[]> {
  const r = await rows<{ data: string }>('SELECT data FROM places ORDER BY name');
  return r.map(parsePlace);
}

export async function getPlace(slug: string): Promise<Place | undefined> {
  const r = await rows<{ data: string }>('SELECT data FROM places WHERE slug = ?', [slug]);
  return r[0] ? parsePlace(r[0]) : undefined;
}

export async function getPublishedExplorations(): Promise<Exploration[]> {
  const r = await rows<{ data: string }>(
    "SELECT data FROM explorations WHERE status = 'publicado' ORDER BY date DESC",
  );
  return r.map(parseExp);
}

export async function getLatestExploration(): Promise<Exploration | undefined> {
  return (await getPublishedExplorations())[0];
}

export async function getExploration(slug: string): Promise<Exploration | undefined> {
  const r = await rows<{ data: string }>('SELECT data FROM explorations WHERE slug = ?', [slug]);
  return r[0] ? parseExp(r[0]) : undefined;
}

export async function getExplorationsForPlace(placeSlug: string): Promise<Exploration[]> {
  const r = await rows<{ data: string }>(
    "SELECT data FROM explorations WHERE place_slug = ? AND status = 'publicado' ORDER BY date DESC",
    [placeSlug],
  );
  return r.map(parseExp);
}

export async function getPlacesInNeighborhood(slug: string): Promise<Place[]> {
  return (await getAllPlaces()).filter((p) => p.neighborhood === slug);
}

export async function getPlacesByCategory(slug: string): Promise<Place[]> {
  return (await getAllPlaces()).filter((p) => p.categories.includes(slug));
}

export async function getExplorationsByCategory(slug: string): Promise<Exploration[]> {
  return (await getPublishedExplorations()).filter((e) => e.categories.includes(slug));
}

export interface MapMarker {
  slug: string;
  name: string;
  neighborhood: string;
  neighborhoodName: string;
  geo: { lat: number; lng: number };
  categories: string[];
  free: boolean;
  favorite: boolean;
  wantToReturn: boolean;
  explorations: number;
  shortDescription: string;
}

/** Marcadores do mapa: só lugares cadastrados (cada um é um lugar visitado). */
export async function getMapMarkers(): Promise<MapMarker[]> {
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  const expCount = new Map<string, number>();
  exps.forEach((e) => expCount.set(e.placeSlug, (expCount.get(e.placeSlug) ?? 0) + 1));
  return places.map((p) => ({
    slug: p.slug,
    name: p.name,
    neighborhood: p.neighborhood,
    neighborhoodName: neighborhoodBySlug.get(p.neighborhood)?.name ?? p.neighborhood,
    geo: p.geo,
    categories: p.categories,
    free: p.price.free,
    favorite: p.favorite,
    wantToReturn: p.wantToReturn,
    explorations: expCount.get(p.slug) ?? 0,
    shortDescription: p.shortDescription,
  }));
}

export async function getStats(): Promise<SiteStats> {
  const [places, exps, settings] = await Promise.all([
    getAllPlaces(),
    getPublishedExplorations(),
    getSettings(),
  ]);
  const totalMinutes = exps.reduce((s, e) => s + e.durationMinutes, 0);
  const totalSpent = exps.reduce((s, e) => s + e.expenses.reduce((a, x) => a + x.amount, 0), 0);
  const photos = exps.reduce((s, e) => s + e.photos.length, 0);
  return {
    places: places.length,
    explorations: exps.length,
    neighborhoods: new Set(places.map((p) => p.neighborhood)).size,
    museums: places.filter((p) => p.categories.includes('museus')).length,
    parks: places.filter((p) => p.categories.includes('parques')).length,
    photos,
    totalMinutes,
    totalSpent: Math.round(totalSpent * 100) / 100,
    kmWalked: Number(settings.kmWalked ?? 0) || places.length * 8,
  };
}

export interface CategoryCount {
  category: Category;
  places: number;
  explorations: number;
}
export async function getCategoryCounts(): Promise<CategoryCount[]> {
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  return allCategories
    .map((category) => ({
      category,
      places: places.filter((p) => p.categories.includes(category.slug)).length,
      explorations: exps.filter((e) => e.categories.includes(category.slug)).length,
    }))
    .filter((c) => c.places > 0)
    .sort((a, b) => b.places - a.places);
}

export interface NeighborhoodSummary {
  neighborhood: Neighborhood;
  places: number;
  explorations: number;
}
export async function getNeighborhoodSummaries(): Promise<NeighborhoodSummary[]> {
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  return allNeighborhoods
    .map((neighborhood) => {
      const inHood = places.filter((p) => p.neighborhood === neighborhood.slug);
      const slugs = new Set(inHood.map((p) => p.slug));
      return {
        neighborhood,
        places: inHood.length,
        explorations: exps.filter((e) => slugs.has(e.placeSlug)).length,
      };
    })
    .filter((s) => s.places > 0)
    .sort((a, b) => b.places - a.places);
}

export async function getRelatedPlaces(place: Place, limit = 6): Promise<Place[]> {
  const places = await getAllPlaces();
  return places
    .filter((p) => p.slug !== place.slug)
    .map((p) => {
      let score = 0;
      if (p.neighborhood === place.neighborhood) score += 4;
      if (p.region === place.region) score += 1;
      score += p.categories.filter((c) => place.categories.includes(c)).length * 2;
      score += Math.max(0, 3 - haversineKm(place.geo, p.geo) / 3);
      return { p, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.p);
}

export interface SearchResult {
  kind: 'place' | 'exploration' | 'neighborhood';
  slug: string;
  title: string;
  subtitle: string;
}
export async function search(query: string): Promise<SearchResult[]> {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const terms = q.split(/\s+/);
  const match = (h: string) => terms.every((t) => h.toLowerCase().includes(t));
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  const out: SearchResult[] = [];
  for (const p of places) {
    if (match([p.name, p.shortDescription, p.neighborhood, ...p.categories, ...p.tags].join(' ')))
      out.push({ kind: 'place', slug: p.slug, title: p.name, subtitle: `Lugar · ${neighborhoodBySlug.get(p.neighborhood)?.name ?? ''}` });
  }
  for (const e of exps) {
    if (match([e.title, e.subtitle ?? '', ...e.tags, ...e.categories].join(' ')))
      out.push({ kind: 'exploration', slug: e.slug, title: e.title, subtitle: 'Exploração' });
  }
  return out.slice(0, 20);
}

// ---- escrita ----
export async function insertPlace(place: Place): Promise<void> {
  await ensureDb();
  await db().execute({
    sql: `INSERT INTO places (slug,name,short_desc,neighborhood,region,lat,lng,is_free,price_max,favorite,want_to_return,recommended_minutes,status,categories,data,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    args: [
      place.slug, place.name, place.shortDescription, place.neighborhood, place.region,
      place.geo.lat, place.geo.lng, place.price.free ? 1 : 0, place.price.max,
      place.favorite ? 1 : 0, place.wantToReturn ? 1 : 0, place.recommendedMinutes ?? null,
      place.status, JSON.stringify(place.categories), JSON.stringify(place), place.createdAt, place.updatedAt,
    ],
  });
}

export async function slugExists(slug: string): Promise<boolean> {
  const r = await rows('SELECT 1 FROM places WHERE slug = ?', [slug]);
  return r.length > 0;
}

// ---- settings ----
export type Settings = Record<string, string>;
export async function getSettings(): Promise<Settings> {
  const r = await rows<{ key: string; value: string }>('SELECT key, value FROM settings');
  const out: Settings = {};
  for (const row of r) out[row.key] = row.value;
  return out;
}
export async function getSetting(key: string): Promise<string | undefined> {
  const r = await rows<{ value: string }>('SELECT value FROM settings WHERE key = ?', [key]);
  return r[0]?.value;
}
export async function setSettings(entries: Record<string, string>): Promise<void> {
  await ensureDb();
  const stmts = Object.entries(entries).map(([key, value]) => ({
    sql: 'INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
    args: [key, value] as never,
  }));
  if (stmts.length) await db().batch(stmts, 'write');
}
