'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { neighborhoods, categories, REGIONS } from '@turistando/core';
import { SPMap } from './SPMap';

export function NovoLugarForm() {
  const router = useRouter();
  const [lat, setLat] = useState(-23.5505);
  const [lng, setLng] = useState(-46.6333);
  const [cats, setCats] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function toggleCat(slug: string) {
    setCats((c) => (c.includes(slug) ? c.filter((x) => x !== slug) : [...c, slug]));
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const fd = new FormData(e.currentTarget);
    const body = {
      name: fd.get('name'),
      shortDescription: fd.get('shortDescription'),
      description: fd.get('description') || '',
      neighborhood: fd.get('neighborhood'),
      region: fd.get('region'),
      lat,
      lng,
      categories: cats,
      tags: String(fd.get('tags') || '').split(',').map((s) => s.trim()).filter(Boolean),
      priceMin: Number(fd.get('priceMin') || 0),
      priceMax: Number(fd.get('priceMax') || 0),
      free: fd.get('free') === 'on',
      favorite: fd.get('favorite') === 'on',
      wantToReturn: fd.get('wantToReturn') === 'on',
      website: fd.get('website') || '',
      instagram: fd.get('instagram') || '',
      hours: fd.get('hours') || '',
      coverImageUrl: fd.get('coverImageUrl') || '',
      recommendedMinutes: fd.get('recommendedMinutes') ? Number(fd.get('recommendedMinutes')) : undefined,
    };
    const res = await fetch('/api/places', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (res.ok) {
      const { data } = await res.json();
      router.push(`/lugares/${data.slug}`);
    } else {
      const err = await res.json().catch(() => ({}));
      setError(err?.error?.message ?? 'Não deu para salvar. Confira os campos.');
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={onSubmit} style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.1fr)', gap: 'clamp(1.5rem,4vw,2.5rem)', alignItems: 'start' }} className="feature-split">
      <div className="stack">
        <Field label="Nome do lugar" required>
          <input className="input" name="name" required placeholder="Ex.: Museu da Língua Portuguesa" />
        </Field>
        <Field label="Descrição curta" required>
          <input className="input" name="shortDescription" required placeholder="Uma frase que resume o lugar" />
        </Field>
        <Field label="Descrição completa">
          <textarea className="input" name="description" rows={3} placeholder="O que é, por que vale, o que esperar" />
        </Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          <Field label="Bairro" required>
            <select className="input" name="neighborhood" required defaultValue="">
              <option value="" disabled>Selecione…</option>
              {neighborhoods.map((n) => <option key={n.slug} value={n.slug}>{n.name}</option>)}
            </select>
          </Field>
          <Field label="Região" required>
            <select className="input" name="region" required defaultValue="centro">
              {REGIONS.map((r) => <option key={r.slug} value={r.slug}>{r.name}</option>)}
            </select>
          </Field>
        </div>

        <Field label="Categorias">
          <div className="chips">
            {categories.map((c) => (
              <button type="button" key={c.slug} className="chip" aria-pressed={cats.includes(c.slug)} onClick={() => toggleCat(c.slug)}>
                {c.name}
              </button>
            ))}
          </div>
        </Field>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem' }}>
          <Field label="Preço mín (R$)"><input className="input" name="priceMin" type="number" min="0" step="0.01" defaultValue="0" /></Field>
          <Field label="Preço máx (R$)"><input className="input" name="priceMax" type="number" min="0" step="0.01" defaultValue="0" /></Field>
          <Field label="Tempo (min)"><input className="input" name="recommendedMinutes" type="number" min="0" placeholder="120" /></Field>
        </div>

        <Field label="Horário"><input className="input" name="hours" placeholder="Ter–Dom, 9h–17h" /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          <Field label="Site"><input className="input" name="website" placeholder="https://…" /></Field>
          <Field label="Instagram"><input className="input" name="instagram" placeholder="@perfil" /></Field>
        </div>
        <Field label="Foto de capa (URL)"><input className="input" name="coverImageUrl" placeholder="https://… (opcional)" /></Field>
        <Field label="Tags (separadas por vírgula)"><input className="input" name="tags" placeholder="gratis, perto-do-metro" /></Field>

        <div style={{ display: 'flex', gap: '1.25rem', flexWrap: 'wrap' }}>
          <label className="check"><input type="checkbox" name="free" /> Gratuito</label>
          <label className="check"><input type="checkbox" name="favorite" /> Favorito</label>
          <label className="check"><input type="checkbox" name="wantToReturn" /> Quero voltar</label>
        </div>

        {error ? <p style={{ color: 'var(--error)' }}>{error}</p> : null}
        <button className="btn btn-accent" type="submit" disabled={submitting} style={{ justifyContent: 'center' }}>
          {submitting ? 'Salvando…' : 'Salvar e colocar no mapa'}
        </button>
      </div>

      <div style={{ position: 'sticky', top: '80px' }}>
        <div className="filter-group__label">Marque no mapa (clique ou arraste o pino) — só São Paulo capital</div>
        <SPMap picker initial={{ lat, lng }} onPick={(la, ln) => { setLat(la); setLng(ln); }} height={420} />
        <div className="coord" style={{ marginTop: '0.75rem', display: 'flex', gap: '1rem' }}>
          <span>LAT {lat.toFixed(6)}</span>
          <span>LNG {lng.toFixed(6)}</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginTop: '0.75rem' }}>
          <Field label="Latitude"><input className="input" value={lat} onChange={(e) => setLat(Number(e.target.value))} type="number" step="0.000001" /></Field>
          <Field label="Longitude"><input className="input" value={lng} onChange={(e) => setLng(Number(e.target.value))} type="number" step="0.000001" /></Field>
        </div>
      </div>
    </form>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="field">
      <span className="field__label">{label}{required ? ' *' : ''}</span>
      {children}
    </label>
  );
}
