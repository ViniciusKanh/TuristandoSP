import 'server-only';
import {
  haversineKm,
  neighborhoodBySlug,
  type Place,
  type Exploration,
  type SiteStats,
  type Category,
  type Neighborhood,
} from '@turistando/core';
import { categories as allCategories } from '@turistando/core';
import { db, ensureDb } from './db';

async function rows<T = unknown>(sql: string, args: unknown[] = []): Promise<T[]> {
  await ensureDb();
  const res = await db().execute({ sql, args: args as never });
  return res.rows as unknown as T[];
}

function parsePlace(row: { data: string }): Place {
  return JSON.parse(row.data) as Place;
}
function parseExp(row: { data: string }): Exploration {
  return JSON.parse(row.data) as Exploration;
}

export async function getAllPlaces(): Promise<Place[]> {
  const r = await rows<{ data: string }>('SELECT data FROM places ORDER BY name');
  return r.map(parsePlace);
}

export async function getPlace(slug: string): Promise<Place | undefined> {
  const r = await rows<{ data: string }>('SELECT data FROM places WHERE slug = ?', [slug]);
  return r[0] ? parsePlace(r[0]) : undefined;
}

export async function getPublishedExplorations(): Promise<Exploration[]> {
  const r = await rows<{ data: string }>(
    "SELECT data FROM explorations WHERE status = 'publicado' ORDER BY date DESC",
  );
  return r.map(parseExp);
}

export async function getLatestExploration(): Promise<Exploration | undefined> {
  return (await getPublishedExplorations())[0];
}

export async function getExploration(slug: string): Promise<Exploration | undefined> {
  const r = await rows<{ data: string }>('SELECT data FROM explorations WHERE slug = ?', [slug]);
  return r[0] ? parseExp(r[0]) : undefined;
}

export async function getExplorationsForPlace(placeSlug: string): Promise<Exploration[]> {
  const r = await rows<{ data: string }>(
    "SELECT data FROM explorations WHERE place_slug = ? AND status = 'publicado' ORDER BY date DESC",
    [placeSlug],
  );
  return r.map(parseExp);
}

export async function getPlacesInNeighborhood(slug: string): Promise<Place[]> {
  return (await getAllPlaces()).filter((p) => p.neighborhood === slug);
}

export async function getPlacesByCategory(slug: string): Promise<Place[]> {
  return (await getAllPlaces()).filter((p) => p.categories.includes(slug));
}

export async function getExplorationsByCategory(slug: string): Promise<Exploration[]> {
  return (await getPublishedExplorations()).filter((e) => e.categories.includes(slug));
}

export interface MapMarker {
  slug: string;
  name: string;
  neighborhood: string;
  neighborhoodName: string;
  geo: { lat: number; lng: number };
  categories: string[];
  free: boolean;
  favorite: boolean;
  wantToReturn: boolean;
  explorations: number;
  shortDescription: string;
}

/** Marcadores do mapa: só lugares cadastrados (cada um é um lugar visitado). */
export async function getMapMarkers(): Promise<MapMarker[]> {
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  const expCount = new Map<string, number>();
  exps.forEach((e) => expCount.set(e.placeSlug, (expCount.get(e.placeSlug) ?? 0) + 1));
  return places.map((p) => ({
    slug: p.slug,
    name: p.name,
    neighborhood: p.neighborhood,
    neighborhoodName: p.neighborhoodName ?? neighborhoodBySlug.get(p.neighborhood)?.name ?? p.neighborhood,
    geo: p.geo,
    categories: p.categories,
    free: p.price.free,
    favorite: p.favorite,
    wantToReturn: p.wantToReturn,
    explorations: expCount.get(p.slug) ?? 0,
    shortDescription: p.shortDescription,
  }));
}

export async function getStats(): Promise<SiteStats> {
  const [places, exps, settings] = await Promise.all([
    getAllPlaces(),
    getPublishedExplorations(),
    getSettings(),
  ]);
  const totalMinutes = exps.reduce((s, e) => s + e.durationMinutes, 0);
  const totalSpent = exps.reduce((s, e) => s + e.expenses.reduce((a, x) => a + x.amount, 0), 0);
  const photos = exps.reduce((s, e) => s + e.photos.length, 0);
  return {
    places: places.length,
    explorations: exps.length,
    neighborhoods: new Set(places.map((p) => p.neighborhood)).size,
    museums: places.filter((p) => p.categories.includes('museus')).length,
    parks: places.filter((p) => p.categories.includes('parques')).length,
    photos,
    totalMinutes,
    totalSpent: Math.round(totalSpent * 100) / 100,
    kmWalked: Number(settings.kmWalked ?? 0) || places.length * 8,
  };
}

export interface CategoryCount {
  category: Category;
  places: number;
  explorations: number;
}
export async function getCategoryCounts(): Promise<CategoryCount[]> {
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  return allCategories
    .map((category) => ({
      category,
      places: places.filter((p) => p.categories.includes(category.slug)).length,
      explorations: exps.filter((e) => e.categories.includes(category.slug)).length,
    }))
    .filter((c) => c.places > 0)
    .sort((a, b) => b.places - a.places);
}

/** Nome de exibição do bairro de um lugar (dinâmico → core → slug). */
export function placeNeighborhoodName(place: Place): string {
  return place.neighborhoodName || neighborhoodBySlug.get(place.neighborhood)?.name || place.neighborhood;
}

/** Bairro montado dinamicamente: usa o core quando existe, senão deriva dos lugares. */
export async function getNeighborhoodView(slug: string): Promise<Neighborhood | undefined> {
  const core = neighborhoodBySlug.get(slug);
  if (core) return core;
  const places = (await getAllPlaces()).filter((p) => p.neighborhood === slug);
  if (places.length === 0) return undefined;
  const p = places[0]!;
  return {
    id: `n-${slug}`,
    slug,
    name: p.neighborhoodName ?? slug,
    region: p.region,
    description: 'Um bairro de São Paulo no meu mapa de explorações.',
    center: p.geo,
  };
}

export interface NeighborhoodSummary {
  neighborhood: Neighborhood;
  places: number;
  explorations: number;
}
export async function getNeighborhoodSummaries(): Promise<NeighborhoodSummary[]> {
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  const placeToHood = new Map(places.map((p) => [p.slug, p.neighborhood]));
  const expByHood = new Map<string, number>();
  for (const e of exps) {
    const h = placeToHood.get(e.placeSlug);
    if (h) expByHood.set(h, (expByHood.get(h) ?? 0) + 1);
  }
  const byHood = new Map<string, { name: string; region: Place['region']; places: number }>();
  for (const p of places) {
    const cur = byHood.get(p.neighborhood) ?? { name: placeNeighborhoodName(p), region: p.region, places: 0 };
    cur.places += 1;
    byHood.set(p.neighborhood, cur);
  }
  return [...byHood.entries()]
    .map(([slug, v]) => {
      const core = neighborhoodBySlug.get(slug);
      const neighborhood: Neighborhood = core ?? {
        id: `n-${slug}`,
        slug,
        name: v.name,
        region: v.region,
        description: 'Um bairro de São Paulo no meu mapa de explorações.',
        center: { lat: 0, lng: 0 },
      };
      return { neighborhood, places: v.places, explorations: expByHood.get(slug) ?? 0 };
    })
    .sort((a, b) => b.places - a.places);
}

export async function getRelatedPlaces(place: Place, limit = 6): Promise<Place[]> {
  const places = await getAllPlaces();
  return places
    .filter((p) => p.slug !== place.slug)
    .map((p) => {
      let score = 0;
      if (p.neighborhood === place.neighborhood) score += 4;
      if (p.region === place.region) score += 1;
      score += p.categories.filter((c) => place.categories.includes(c)).length * 2;
      score += Math.max(0, 3 - haversineKm(place.geo, p.geo) / 3);
      return { p, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.p);
}

export interface SearchResult {
  kind: 'place' | 'exploration' | 'neighborhood';
  slug: string;
  title: string;
  subtitle: string;
}
export async function search(query: string): Promise<SearchResult[]> {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const terms = q.split(/\s+/);
  const match = (h: string) => terms.every((t) => h.toLowerCase().includes(t));
  const [places, exps] = await Promise.all([getAllPlaces(), getPublishedExplorations()]);
  const out: SearchResult[] = [];
  for (const p of places) {
    if (match([p.name, p.shortDescription, p.neighborhood, ...p.categories, ...p.tags].join(' ')))
      out.push({ kind: 'place', slug: p.slug, title: p.name, subtitle: `Lugar · ${neighborhoodBySlug.get(p.neighborhood)?.name ?? ''}` });
  }
  for (const e of exps) {
    if (match([e.title, e.subtitle ?? '', ...e.tags, ...e.categories].join(' ')))
      out.push({ kind: 'exploration', slug: e.slug, title: e.title, subtitle: 'Exploração' });
  }
  return out.slice(0, 20);
}

// ---- escrita ----
export async function insertPlace(place: Place): Promise<void> {
  await ensureDb();
  await db().execute({
    sql: `INSERT INTO places (slug,name,short_desc,neighborhood,region,lat,lng,is_free,price_max,favorite,want_to_return,recommended_minutes,status,categories,data,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    args: [
      place.slug, place.name, place.shortDescription, place.neighborhood, place.region,
      place.geo.lat, place.geo.lng, place.price.free ? 1 : 0, place.price.max,
      place.favorite ? 1 : 0, place.wantToReturn ? 1 : 0, place.recommendedMinutes ?? null,
      place.status, JSON.stringify(place.categories), JSON.stringify(place), place.createdAt, place.updatedAt,
    ],
  });
}

export async function slugExists(slug: string): Promise<boolean> {
  const r = await rows('SELECT 1 FROM places WHERE slug = ?', [slug]);
  return r.length > 0;
}

export async function updatePlace(slug: string, place: Place): Promise<void> {
  await ensureDb();
  await db().execute({
    sql: `UPDATE places SET name=?,short_desc=?,neighborhood=?,region=?,lat=?,lng=?,is_free=?,price_max=?,favorite=?,want_to_return=?,recommended_minutes=?,status=?,categories=?,data=?,updated_at=?
          WHERE slug=?`,
    args: [
      place.name, place.shortDescription, place.neighborhood, place.region,
      place.geo.lat, place.geo.lng, place.price.free ? 1 : 0, place.price.max,
      place.favorite ? 1 : 0, place.wantToReturn ? 1 : 0, place.recommendedMinutes ?? null,
      place.status, JSON.stringify(place.categories), JSON.stringify(place), place.updatedAt, slug,
    ],
  });
}

export async function deletePlace(slug: string): Promise<void> {
  await ensureDb();
  await db().execute({ sql: 'DELETE FROM places WHERE slug = ?', args: [slug] });
}

// ---- settings (delegam para o serviço de config em arquivo, gerenciado pelo painel) ----
import { getConfig, setConfig, type AppConfig } from './config';

const SECRET_KEYS = new Set(['tursoToken', 'geminiApiKey', 'adminPassword']);

export type Settings = Record<string, string>;
/** Config pública (sem segredos e sem valores vazios) — usada nas páginas. */
export async function getSettings(): Promise<Settings> {
  const c = getConfig();
  const out: Settings = {};
  for (const [k, v] of Object.entries(c)) {
    if (v === '' || SECRET_KEYS.has(k)) continue;
    out[k] = v as string;
  }
  return out;
}
export async function getSetting(key: keyof AppConfig): Promise<string | undefined> {
  const v = getConfig()[key];
  return v === '' ? undefined : v;
}
export async function setSettings(entries: Partial<AppConfig>): Promise<void> {
  setConfig(entries);
}
