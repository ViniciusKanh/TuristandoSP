import 'server-only';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';

/**
 * Configuração do projeto gerenciada PELO PAINEL (sem .env).
 * Guardada num arquivo JSON local (gitignored). Variáveis de ambiente, se
 * existirem, têm precedência — assim dá pra usar o painel no seu PC e as
 * variáveis da Vercel em produção, sem editar arquivo nenhum.
 */
export interface AppConfig {
  tursoUrl: string;
  tursoToken: string;
  geminiApiKey: string;
  geminiModel: string;
  adminPassword: string;
  siteName: string;
  tagline: string;
  heroHeadline: string;
  heroImageUrl: string;
  instagram: string;
  kmWalked: string;
}

const SECRET_KEYS: (keyof AppConfig)[] = ['tursoToken', 'geminiApiKey', 'adminPassword'];

const configFile = process.env.VERCEL
  ? join(tmpdir(), 'turistando-config.json')
  : join(process.cwd(), '.data', 'config.json');

let cache: Partial<AppConfig> | null = null;
let version = 0;

function loadFile(): Partial<AppConfig> {
  if (cache) return cache;
  try {
    cache = JSON.parse(readFileSync(configFile, 'utf8')) as Partial<AppConfig>;
  } catch {
    cache = {};
  }
  return cache;
}

/** Config efetiva (env sobrepõe arquivo). */
export function getConfig(): AppConfig {
  const f = loadFile();
  return {
    tursoUrl: process.env.TURSO_DATABASE_URL || f.tursoUrl || '',
    tursoToken: process.env.TURSO_AUTH_TOKEN || f.tursoToken || '',
    geminiApiKey: process.env.GEMINI_API_KEY || f.geminiApiKey || '',
    geminiModel: f.geminiModel || process.env.GEMINI_MODEL || 'gemini-1.5-flash',
    adminPassword: process.env.ADMIN_PASSWORD || f.adminPassword || 'turistando',
    siteName: f.siteName || '',
    tagline: f.tagline || '',
    heroHeadline: f.heroHeadline || '',
    heroImageUrl: f.heroImageUrl || '',
    instagram: f.instagram || '',
    kmWalked: f.kmWalked || '',
  };
}

/** Grava no arquivo (merge). Retorna a versão nova (para invalidar o cliente do banco). */
export function setConfig(partial: Partial<AppConfig>): number {
  const f = { ...loadFile() };
  for (const [k, v] of Object.entries(partial)) {
    if (v === undefined) continue;
    if (v === '') {
      // string vazia não apaga segredo existente (mantém o que já foi salvo)
      if (SECRET_KEYS.includes(k as keyof AppConfig)) continue;
    }
    (f as Record<string, unknown>)[k] = v;
  }
  try {
    mkdirSync(dirname(configFile), { recursive: true });
  } catch {
    /* ignore */
  }
  writeFileSync(configFile, JSON.stringify(f, null, 2), 'utf8');
  cache = f;
  version += 1;
  return version;
}

export function configVersion(): number {
  return version;
}

export function tursoConfigured(): boolean {
  return Boolean(getConfig().tursoUrl);
}

export function geminiConfigured(): boolean {
  return Boolean(getConfig().geminiApiKey);
}

/** Máscara para exibir se um segredo está salvo, sem revelar o valor. */
export function maskSecret(value: string): string {
  if (!value) return '';
  return '••••••••' + value.slice(-4);
}
