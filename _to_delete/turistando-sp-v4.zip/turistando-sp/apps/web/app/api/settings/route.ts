import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { z } from 'zod';
import { SESSION_COOKIE, verifySession } from '@/lib/auth';
import { getConfig, setConfig, maskSecret } from '@/lib/config';

const SettingsInput = z.object({
  siteName: z.string().optional(),
  tagline: z.string().optional(),
  heroImageUrl: z.string().url().optional().or(z.literal('')),
  heroHeadline: z.string().optional(),
  instagram: z.string().optional(),
  kmWalked: z.string().optional(),
  geminiApiKey: z.string().optional(),
  geminiModel: z.string().optional(),
  tursoUrl: z.string().optional(),
  tursoToken: z.string().optional(),
  adminPassword: z.string().optional(),
});

export async function GET() {
  if (!(await verifySession(cookies().get(SESSION_COOKIE)?.value)))
    return NextResponse.json({ error: { message: 'Não autenticado' } }, { status: 401 });
  const c = getConfig();
  return NextResponse.json({
    data: {
      siteName: c.siteName, tagline: c.tagline, heroHeadline: c.heroHeadline,
      heroImageUrl: c.heroImageUrl, instagram: c.instagram, kmWalked: c.kmWalked,
      geminiModel: c.geminiModel, tursoUrl: c.tursoUrl,
      geminiApiKey: maskSecret(c.geminiApiKey), tursoToken: maskSecret(c.tursoToken),
      adminPassword: c.adminPassword ? '••••••••' : '',
    },
  });
}

export async function POST(req: Request) {
  if (!(await verifySession(cookies().get(SESSION_COOKIE)?.value)))
    return NextResponse.json({ error: { message: 'Não autenticado' } }, { status: 401 });

  const ct = req.headers.get('content-type') ?? '';
  const raw = ct.includes('application/json')
    ? await req.json()
    : Object.fromEntries((await req.formData()).entries());

  const parsed = SettingsInput.safeParse(raw);
  if (!parsed.success)
    return NextResponse.json({ error: { message: 'Validação falhou', issues: parsed.error.flatten() } }, { status: 400 });

  const entries: Record<string, string> = {};
  for (const [k, val] of Object.entries(parsed.data)) {
    if (val === undefined) continue;
    if (typeof val === 'string' && val.startsWith('••••')) continue; // ignora valores mascarados
    entries[k] = String(val);
  }
  setConfig(entries);

  const accept = req.headers.get('accept') ?? '';
  if (!accept.includes('application/json')) {
    return NextResponse.redirect(new URL('/admin/configuracoes?saved=1', req.url), 303);
  }
  return NextResponse.json({ ok: true });
}
