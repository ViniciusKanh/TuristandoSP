import type { Metadata } from 'next';
import { getConfig, tursoConfigured, geminiConfigured } from '@/lib/config';
import { siteConfig } from '@turistando/core';
import { UrbanLabel } from '@/components/brand';
import { TestConnection } from '@/components/feature/TestConnection';

export const metadata: Metadata = { title: 'Configurações', robots: { index: false } };
export const dynamic = 'force-dynamic';

export default async function ConfiguracoesPage({ searchParams }: { searchParams: { saved?: string } }) {
  const c = getConfig();
  const usingEnvTurso = Boolean(process.env.TURSO_DATABASE_URL);

  return (
    <div className="section container container-wide" style={{ maxWidth: '920px' }}>
      <UrbanLabel>Painel · Tudo se configura aqui (sem .env)</UrbanLabel>
      <h1 className="display title-lg" style={{ marginTop: '0.6rem' }}>Configurações</h1>
      <p className="lead" style={{ marginTop: '0.75rem' }}>
        Cole aqui as chaves do Turso e do Gemini, a imagem de fundo e a identidade. Tudo é salvo num arquivo de configuração local (protegido, fora do Git) — você não precisa mexer em nenhum arquivo.
      </p>
      {searchParams.saved ? <p className="mono" style={{ color: 'var(--green)', marginTop: '0.75rem' }}>✓ Salvo.</p> : null}

      {/* BANCO TURSO */}
      <Card title="Banco de dados — Turso" desc="Sem preencher, o site usa um banco local automaticamente. Cole a URL e o token do seu banco Turso e salve — a conexão passa a valer na hora.">
        <div style={{ marginBottom: '1rem' }}>
          <span className="tag" style={{ borderColor: tursoConfigured() ? 'var(--green)' : 'var(--border-strong)', color: tursoConfigured() ? 'var(--green)' : 'var(--text-faint)' }}>
            {tursoConfigured() ? 'Turso conectado' : 'Banco local (arquivo)'}
          </span>
        </div>
        {usingEnvTurso ? (
          <p className="muted" style={{ fontSize: '0.9rem' }}>Detectei credenciais do Turso nas variáveis de ambiente — elas têm prioridade sobre o que você salvar aqui.</p>
        ) : (
          <form action="/api/settings" method="post" className="stack">
            <Field label="TURSO_DATABASE_URL"><input className="input mono" name="tursoUrl" defaultValue={c.tursoUrl} placeholder="libsql://seu-banco.turso.io" /></Field>
            <Field label="TURSO_AUTH_TOKEN"><input className="input mono" name="tursoToken" type="password" placeholder={c.tursoToken ? '•••••••• (salvo — deixe em branco para manter)' : 'eyJ...'} /></Field>
            <button className="btn btn-sm" type="submit">Salvar conexão do Turso</button>
          </form>
        )}
        <TestConnection target="turso" label="Testar conexão do banco" />
        <p className="muted" style={{ fontSize: '0.82rem', marginTop: '0.75rem' }}>
          Crie o banco com a CLI: <code className="mono">turso db create turistando-sp</code>, depois pegue a URL (<code className="mono">turso db show --url</code>) e um token (<code className="mono">turso db tokens create</code>). Salve aqui e teste.
        </p>
      </Card>

      {/* GEMINI */}
      <Card title="Google Gemini" desc="A chave organiza texto e fotos ao publicar. Fica salva no arquivo de config local (nunca vai para o navegador nem para o Git).">
        <form action="/api/settings" method="post" className="stack">
          <Field label="API Key do Gemini"><input className="input mono" name="geminiApiKey" type="password" placeholder={geminiConfigured() ? '•••••••• (salva — deixe em branco para manter)' : 'AIza…'} /></Field>
          <Field label="Modelo"><input className="input" name="geminiModel" defaultValue={c.geminiModel} /></Field>
          <button className="btn btn-sm" type="submit">Salvar chave</button>
        </form>
        <TestConnection target="gemini" label="Testar chave do Gemini" />
        <p className="muted" style={{ fontSize: '0.82rem', marginTop: '0.75rem' }}>Salve a chave e depois teste. Pegue a chave em aistudio.google.com/apikey.</p>
      </Card>

      {/* IDENTIDADE */}
      <Card title="Identidade do site" desc="O nome ainda é provisório — troque aqui e vale no site inteiro.">
        <form action="/api/settings" method="post" className="stack">
          <Field label="Nome do site"><input className="input" name="siteName" defaultValue={c.siteName || siteConfig.siteName} /></Field>
          <Field label="Tagline"><input className="input" name="tagline" defaultValue={c.tagline || siteConfig.tagline} /></Field>
          <Field label="Manchete da Home"><input className="input" name="heroHeadline" defaultValue={c.heroHeadline || 'São Paulo é grande demais para conhecer de uma vez.'} /></Field>
          <Field label="Instagram"><input className="input" name="instagram" defaultValue={c.instagram} placeholder="@turistandosp" /></Field>
          <Field label="Km rodados (aparece na Home)"><input className="input" name="kmWalked" defaultValue={c.kmWalked} placeholder="312" /></Field>
          <button className="btn btn-sm" type="submit">Salvar identidade</button>
        </form>
      </Card>

      {/* IMAGEM DE FUNDO */}
      <Card title="Imagem de fundo (Home)" desc="Cole a URL de uma foto sua para o fundo do topo da Home. Sem imagem, usamos um fundo tipográfico limpo.">
        <form action="/api/settings" method="post" className="stack">
          <Field label="URL da imagem de fundo"><input className="input" name="heroImageUrl" defaultValue={c.heroImageUrl} placeholder="https://…" /></Field>
          <button className="btn btn-sm" type="submit">Salvar imagem</button>
        </form>
        {c.heroImageUrl ? (
          <div className="photo" style={{ aspectRatio: '16/6', marginTop: '1rem' }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.heroImageUrl} alt="Prévia do fundo" />
          </div>
        ) : null}
      </Card>

      {/* SENHA DO PAINEL */}
      <Card title="Senha do painel" desc="A senha de acesso a este painel. Padrão de desenvolvimento: turistando.">
        <form action="/api/settings" method="post" className="stack">
          <Field label="Nova senha"><input className="input" name="adminPassword" type="password" placeholder="deixe em branco para manter a atual" /></Field>
          <button className="btn btn-sm" type="submit">Salvar senha</button>
        </form>
      </Card>
    </div>
  );
}

function Card({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <section style={{ border: '1px solid var(--border)', background: 'var(--surface)', padding: 'clamp(1.25rem, 3vw, 2rem)', marginTop: '1.5rem' }}>
      <h2 className="heading h3" style={{ fontSize: '1.25rem' }}>{title}</h2>
      <p className="muted" style={{ fontSize: '0.92rem', margin: '0.4rem 0 1.25rem', maxWidth: '62ch' }}>{desc}</p>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="field">
      <span className="field__label">{label}</span>
      {children}
    </label>
  );
}
