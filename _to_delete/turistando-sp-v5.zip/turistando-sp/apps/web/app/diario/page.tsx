import type { Metadata } from 'next';
import { placeBySlug } from '@turistando/core';
import { getPublishedExplorations } from '@/lib/repo';
import { UrbanLabel } from '@/components/brand';
import { ExplorationCard } from '@/components/cards';

export const metadata: Metadata = {
  title: 'Diário',
  description: 'Todas as minhas explorações pela cidade de São Paulo, uma parada por vez.',
  alternates: { canonical: '/diario' },
};
export const dynamic = 'force-dynamic';

export default async function DiarioPage() {
  const exps = await getPublishedExplorations();
  return (
    <div className="section container container-wide">
      <div className="eyebrow"><UrbanLabel>Diário de bordo · {exps.length} paradas</UrbanLabel></div>
      <h1 className="display title-xl" style={{ maxWidth: '16ch' }}>O que eu andei turistando</h1>
      <p className="lead" style={{ marginTop: '1rem', marginBottom: '2.5rem' }}>
        Cada saída vira uma rota, e cada rota vira um relato. Do mais recente ao começo de tudo.
      </p>
      {exps.length === 0 ? (
        <div className="empty-state">Nenhuma exploração publicada ainda.</div>
      ) : (
        <div className="grid grid-4">
          {exps.map((e) => (<ExplorationCard key={e.id} exp={e} place={placeBySlug.get(e.placeSlug)} />))}
        </div>
      )}
    </div>
  );
}
