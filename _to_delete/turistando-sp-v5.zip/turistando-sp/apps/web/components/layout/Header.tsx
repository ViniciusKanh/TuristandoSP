import Link from 'next/link';
import { siteConfig } from '@turistando/core';
import { Mark, Search, Home, Compass, MapIcon, Book } from '../brand/Icons';
import { ThemeToggle } from './ThemeToggle';

const NAV = [
  { href: '/explorar', label: 'Explorar' },
  { href: '/lugares', label: 'Lugares' },
  { href: '/bairros', label: 'Bairros' },
  { href: '/mapa', label: 'Mapa' },
  { href: '/diario', label: 'Diário' },
  { href: '/sobre', label: 'Sobre' },
];

export function Header() {
  const name = siteConfig.siteShortName.replace(siteConfig.logoAccent, '');
  return (
    <>
      <header className="site-header">
        <div className="container container-wide site-header__inner">
          <Link href="/" className="brand" aria-label={siteConfig.siteName}>
            <Mark className="brand__mark" aria-hidden />
            <span>
              {name.trim()}
              <span className="brand__accent">{siteConfig.logoAccent}</span>
            </span>
          </Link>
          <nav className="nav" aria-label="Principal">
            {NAV.map((i) => (
              <Link key={i.href} href={i.href}>
                {i.label}
              </Link>
            ))}
          </nav>
          <div className="header-actions">
            <Link href="/explorar" className="icon-btn" aria-label="Buscar">
              <Search aria-hidden />
            </Link>
            <ThemeToggle />
            <Link href="/admin" className="btn btn-ghost btn-sm" style={{ borderColor: 'var(--border-strong)' }}>
              Painel
            </Link>
          </div>
        </div>
      </header>

      <nav className="mobile-nav" aria-label="Navegação mobile">
        <Link href="/"><Home aria-hidden /> Início</Link>
        <Link href="/explorar"><Compass aria-hidden /> Explorar</Link>
        <Link href="/mapa"><MapIcon aria-hidden /> Mapa</Link>
        <Link href="/diario"><Book aria-hidden /> Diário</Link>
      </nav>
    </>
  );
}
