import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import type { ArticleBlock, PhotoRef } from '@turistando/core';
import { SESSION_COOKIE, verifySession } from '@/lib/auth';
import { getSetting } from '@/lib/repo';
import { fallbackArticle } from '@/lib/explorationInput';

interface Body {
  placeName?: string;
  neighborhood?: string;
  date?: string;
  rawText?: string;
  photos?: PhotoRef[];
}

const PROMPT = (b: Body) => {
  const photos = (b.photos ?? []).map((p, i) => `Foto ${i}: ${p.alt || 'sem descrição'}`).join('\n');
  return `Você é um editor de um jornal de viagem. Recebe o relato bruto de uma visita e organiza num artigo bonito, no estilo de página de jornal, em português do Brasil.

LUGAR: ${b.placeName ?? ''} — ${b.neighborhood ?? ''}
DATA: ${b.date ?? ''}
FOTOS DISPONÍVEIS (use o índice para posicioná-las):
${photos || '(nenhuma)'}

RELATO BRUTO DO AUTOR:
"""
${b.rawText ?? ''}
"""

Devolva SOMENTE um JSON válido com esta forma:
{
  "title": "título curto e forte (máx ~70 caracteres)",
  "subtitle": "linha fina / olho da matéria (1 frase)",
  "blocks": [ { "type": "...", ... } ]
}

Tipos de bloco permitidos:
- {"type":"paragraph","text":"..."}
- {"type":"heading","level":2,"text":"..."}
- {"type":"quote","text":"uma frase de destaque tirada/inspirada no relato"}
- {"type":"tip","title":"Minha dica","text":"..."}
- {"type":"info","title":"Vale saber","text":"..."}
- {"type":"image","photo": <índice da foto>}
- {"type":"gallery","photos":[<índices>]}

REGRAS:
- Mantenha a voz do autor (primeira pessoa), corrija clareza e pontuação, NÃO invente fatos.
- Comece com um parágrafo de abertura forte (lide).
- Use de 2 a 4 headings para dar ritmo.
- Inclua 1 "quote" de destaque e 1 "tip" (e "info" se fizer sentido).
- A foto 0 é a CAPA (já aparece no topo) — use as fotos de 1 em diante no corpo, cada uma UMA vez, distribuídas entre parágrafos; sobras vão numa "gallery" no fim.
- Não inclua nenhum texto fora do JSON.`;
};

function resolveBlocks(rawBlocks: unknown[], photos: PhotoRef[]): ArticleBlock[] {
  const out: ArticleBlock[] = [];
  const at = (i: unknown) => {
    const idx = Number(i);
    return Number.isFinite(idx) ? photos[idx] : undefined;
  };
  for (const r of Array.isArray(rawBlocks) ? rawBlocks : []) {
    if (!r || typeof r !== 'object') continue;
    const b = r as Record<string, unknown>;
    switch (String(b.type)) {
      case 'paragraph': if (b.text) out.push({ type: 'paragraph', text: String(b.text) }); break;
      case 'heading': out.push({ type: 'heading', level: b.level === 3 ? 3 : 2, text: String(b.text ?? '') }); break;
      case 'quote': if (b.text) out.push({ type: 'quote', text: String(b.text) }); break;
      case 'tip': if (b.text) out.push({ type: 'tip', title: b.title ? String(b.title) : 'Minha dica', text: String(b.text) }); break;
      case 'info': if (b.text) out.push({ type: 'info', title: b.title ? String(b.title) : 'Vale saber', text: String(b.text) }); break;
      case 'warning': if (b.text) out.push({ type: 'warning', title: b.title ? String(b.title) : 'Atenção', text: String(b.text) }); break;
      case 'image': { const p = at(b.photo); if (p?.url) out.push({ type: 'image', photo: p }); break; }
      case 'gallery': {
        const ps = (Array.isArray(b.photos) ? b.photos : []).map(at).filter((p): p is PhotoRef => Boolean(p?.url));
        if (ps.length) out.push({ type: 'gallery', photos: ps });
        break;
      }
      default: break;
    }
  }
  return out;
}

/** Descobre um modelo válido para generateContent na conta do usuário. */
async function pickModel(key: string, preferred: string): Promise<string | null> {
  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`);
    if (!r.ok) return preferred || 'gemini-2.0-flash';
    const j = (await r.json()) as { models?: { name: string; supportedGenerationMethods?: string[] }[] };
    const names = (j.models ?? [])
      .filter((m) => (m.supportedGenerationMethods ?? []).includes('generateContent'))
      .map((m) => m.name.replace(/^models\//, ''));
    if (preferred && names.includes(preferred)) return preferred;
    const find = (re: RegExp) => names.find((n) => re.test(n));
    return (
      find(/gemini-2\.\d.*flash(?!.*(exp|thinking))/) ||
      find(/flash-latest/) ||
      find(/gemini-2\.\d.*flash/) ||
      find(/flash/) ||
      find(/gemini-2\.\d.*pro/) ||
      find(/pro/) ||
      names[0] ||
      null
    );
  } catch {
    return preferred || 'gemini-2.0-flash';
  }
}

export async function POST(req: Request) {
  if (!(await verifySession(cookies().get(SESSION_COOKIE)?.value))) {
    return NextResponse.json({ error: { message: 'Não autenticado' } }, { status: 401 });
  }
  const body = (await req.json().catch(() => ({}))) as Body;
  const photos = body.photos ?? [];
  const key = await getSetting('geminiApiKey');
  const preferred = (await getSetting('geminiModel')) || '';

  // Sem chave → fallback local (funciona mesmo assim).
  if (!key) {
    return NextResponse.json({ data: { blocks: fallbackArticle(body.rawText ?? '', photos), source: 'fallback', message: 'Sem chave do Gemini — organizei localmente. Configure a chave em Configurações para um resultado melhor.' } });
  }

  const model = await pickModel(key, preferred);
  if (!model) {
    return NextResponse.json({ data: { blocks: fallbackArticle(body.rawText ?? '', photos), source: 'fallback', message: 'Nenhum modelo do Gemini com generateContent disponível na sua conta. Usei o modo local.' } });
  }

  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: PROMPT(body) }] }],
        generationConfig: { responseMimeType: 'application/json', temperature: 0.7, maxOutputTokens: 4096 },
      }),
    });
    if (!res.ok) {
      const detail = (await res.text()).slice(0, 300);
      return NextResponse.json({ data: { blocks: fallbackArticle(body.rawText ?? '', photos), source: 'fallback', message: `Gemini respondeu ${res.status}. Usei o modo local. (${detail})` } });
    }
    const json = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    const text = json.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
    const parsed = JSON.parse(text) as { title?: string; subtitle?: string; blocks?: unknown[] };
    const blocks = resolveBlocks(parsed.blocks ?? [], photos);
    if (blocks.length === 0) {
      return NextResponse.json({ data: { blocks: fallbackArticle(body.rawText ?? '', photos), source: 'fallback', message: 'O Gemini não retornou blocos úteis; usei o modo local.' } });
    }
    return NextResponse.json({ data: { title: parsed.title, subtitle: parsed.subtitle, blocks, source: 'gemini' } });
  } catch (e) {
    return NextResponse.json({ data: { blocks: fallbackArticle(body.rawText ?? '', photos), source: 'fallback', message: `Falha ao chamar o Gemini (${(e as Error).message}); usei o modo local.` } });
  }
}
