import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import {
  neighborhoodBySlug,
  siteConfig,
  formatDateLong,
  formatDuration,
  formatBRL,
  formatExplorationNumber,
  TRANSPORT_LABEL,
} from '@turistando/core';
import { getExploration, getPlace } from '@/lib/repo';
import { Photo } from '@/components/brand/Photo';
import { UrbanLabel, Rating, Coordinates, WouldReturnLabel, Tag } from '@/components/brand';
import { ArticleRenderer } from '@/components/feature/ArticleRenderer';
import { ShareButton } from '@/components/feature/ShareButton';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const exp = await getExploration(params.slug);
  if (!exp) return {};
  const place = await getPlace(exp.placeSlug);
  return {
    title: exp.title,
    description: exp.subtitle ?? `${formatExplorationNumber(exp.number)} — ${place?.name ?? ''}`,
    alternates: { canonical: `/exploracoes/${exp.slug}` },
    openGraph: { type: 'article', title: exp.title, description: exp.subtitle ?? '', publishedTime: exp.publishedAt },
  };
}

export default async function ExplorationPage({ params }: { params: { slug: string } }) {
  const exp = await getExploration(params.slug);
  if (!exp || exp.status !== 'publicado') notFound();
  const place = await getPlace(exp.placeSlug);
  const hoodName = place ? place.neighborhoodName || neighborhoodBySlug.get(place.neighborhood)?.name || place.neighborhood : '';
  const total = exp.expenses.reduce((s, e) => s + e.amount, 0);
  const r = exp.rating;

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: exp.title,
    datePublished: exp.publishedAt,
    author: { '@type': 'Person', name: siteConfig.authorName },
    about: place ? { '@type': 'TouristAttraction', name: place.name } : undefined,
    inLanguage: 'pt-BR',
  };

  const dims: Array<[string, number | undefined]> = [
    ['Experiência', r.experience],
    ['Custo-benefício', r.costBenefit],
    ['Infraestrutura', r.infrastructure],
    ['Acessibilidade', r.accessibility],
    ['Fotografia', r.photography],
  ];

  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="container container-wide" style={{ paddingTop: '2rem' }}>
        <nav className="crumbs" aria-label="Trilha">
          <Link href="/">Início</Link> <span>/</span>
          <Link href="/diario">Diário</Link> <span>/</span>
          <span style={{ color: 'var(--text-muted)' }}>{formatExplorationNumber(exp.number)}</span>
        </nav>
        <header className="exp-masthead" style={{ marginTop: '2.5rem', maxWidth: '46rem', marginInline: 'auto', textAlign: 'center' }}>
          <div className="exp-dateline">
            <span>{siteConfig.siteShortName}</span>
            <span>·</span>
            <span>{formatExplorationNumber(exp.number)}</span>
            <span>·</span>
            <span>{formatDateLong(exp.date)}</span>
          </div>
          <h1 className="display title-xl" style={{ marginTop: '1.25rem' }}>{exp.title}</h1>
          {exp.subtitle ? <p className="lead" style={{ marginTop: '1rem', marginInline: 'auto', fontStyle: 'italic' }}>{exp.subtitle}</p> : null}
          {place ? (
            <p className="coord" style={{ marginTop: '1rem' }}>
              <Link href={`/lugares/${place.slug}`} style={{ borderBottom: '2px solid var(--accent)' }}>{place.name}</Link>
              {' · '}{hoodName} · {siteConfig.city}
            </p>
          ) : null}
          <div style={{ marginTop: '1.25rem', display: 'flex', gap: '0.6rem', justifyContent: 'center' }}>
            <ShareButton title={exp.title} path={`/exploracoes/${exp.slug}`} />
          </div>
          <hr className="divider" style={{ marginTop: '1.75rem', borderTopWidth: '2px', borderColor: 'var(--primary)' }} />
        </header>
      </div>

      {(() => {
        const cover = exp.photos[0] ?? place?.coverImage;
        return cover ? (
          <div className="container container-wide" style={{ marginTop: '2rem' }}>
            <Photo photo={cover} priority showCaption />
          </div>
        ) : null;
      })()}

      <div className="container container-wide" style={{ marginTop: '2rem' }}>
        <div className="ficha">
          <div className="ficha__cell"><div className="ficha__val">{r.overall}</div><div className="ficha__key">Minha nota</div></div>
          <div className="ficha__cell"><div className="ficha__val" style={{ fontSize: '1.6rem' }}>{total > 0 ? formatBRL(total) : 'Grátis'}</div><div className="ficha__key">Quanto paguei</div></div>
          <div className="ficha__cell"><div className="ficha__val">{formatDuration(exp.durationMinutes)}</div><div className="ficha__key">Quanto fiquei</div></div>
          <div className="ficha__cell"><div className="ficha__val" style={{ fontSize: '1.3rem' }}>{exp.transport.map((t) => TRANSPORT_LABEL[t.mode]).join(' + ')}</div><div className="ficha__key">Como cheguei</div></div>
          <div className="ficha__cell"><div className="ficha__val" style={{ fontSize: '1.3rem' }}><WouldReturnLabel value={r.wouldReturn} /></div><div className="ficha__key">Eu voltaria?</div></div>
        </div>
      </div>

      <div className="section container container-wide">
        <ArticleRenderer blocks={exp.article} />
      </div>

      <section className="section-tight container container-wide">
        <div className="section-head">
          <div><UrbanLabel>Avaliação</UrbanLabel><h2 className="heading h2" style={{ marginTop: '0.6rem' }}>O que eu achei, por partes</h2></div>
          <Rating value={r.overall} size={22} />
        </div>
        <div className="grid grid-3">
          {dims.filter(([, v]) => v != null).map(([label, v]) => (
            <div className="mini-card" key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="u-label" style={{ color: 'var(--text-muted)' }}>{label}</span>
              <Rating value={v as number} />
            </div>
          ))}
        </div>
        {exp.tags.length ? (
          <div className="tag-row" style={{ marginTop: '1.5rem' }}>
            {exp.tags.map((t) => (<Tag key={t} slug={t}>{t.replace(/-/g, ' ')}</Tag>))}
          </div>
        ) : null}
      </section>

      {place ? (
        <section className="section-tight container container-wide">
          <div className="mini-card" style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <span className="u-label">Sobre este lugar</span>
              <div className="h3" style={{ fontSize: '1.4rem', marginTop: '0.4rem' }}>{place.name}</div>
              <Coordinates geo={place.geo} />
            </div>
            <Link href={`/lugares/${place.slug}`} className="btn">Ver todas as minhas visitas aqui</Link>
          </div>
        </section>
      ) : null}
    </article>
  );
}
