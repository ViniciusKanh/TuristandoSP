'use client';

import 'leaflet/dist/leaflet.css';
import { useEffect, useRef } from 'react';
import type { MapMarker } from '@/lib/repo';

// Limites da cidade de São Paulo (capital).
const SP_BOUNDS: [[number, number], [number, number]] = [
  [-24.01, -46.83], // sudoeste
  [-23.35, -46.36], // nordeste
];
const SP_CENTER: [number, number] = [-23.5505, -46.6333];

export interface SPMapProps {
  markers?: MapMarker[];
  /** modo seletor: chama onPick com a coordenada clicada */
  picker?: boolean;
  initial?: { lat: number; lng: number };
  onPick?: (lat: number, lng: number) => void;
  height?: number | string;
}

export function SPMap({ markers = [], picker = false, initial, onPick, height = 520 }: SPMapProps) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<unknown>(null);
  const pickMarkerRef = useRef<unknown>(null);

  useEffect(() => {
    let disposed = false;
    (async () => {
      const L = (await import('leaflet')).default;
      if (disposed || !ref.current || mapRef.current) return;

      const map = L.map(ref.current, {
        center: initial ? [initial.lat, initial.lng] : SP_CENTER,
        zoom: 12,
        minZoom: 10,
        maxZoom: 18,
        maxBounds: SP_BOUNDS,
        maxBoundsViscosity: 0.9,
        scrollWheelZoom: false,
      });
      mapRef.current = map;

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        maxZoom: 19,
      }).addTo(map);

      const dot = (color: string, size = 16) =>
        L.divIcon({
          className: 'sp-pin',
          html: `<span style="display:block;width:${size}px;height:${size}px;border-radius:50%;background:${color};border:2px solid #2A1E13;box-shadow:0 1px 4px rgba(0,0,0,.4)"></span>`,
          iconSize: [size, size],
          iconAnchor: [size / 2, size / 2],
        });

      if (picker) {
        const start = initial ?? { lat: SP_CENTER[0], lng: SP_CENTER[1] };
        const m = L.marker([start.lat, start.lng], { draggable: true, icon: dot('#B0812C', 20) }).addTo(map);
        pickMarkerRef.current = m;
        const emit = (lat: number, lng: number) => onPick?.(Math.round(lat * 1e6) / 1e6, Math.round(lng * 1e6) / 1e6);
        m.on('dragend', () => {
          const p = m.getLatLng();
          emit(p.lat, p.lng);
        });
        map.on('click', (e: { latlng: { lat: number; lng: number } }) => {
          m.setLatLng(e.latlng);
          emit(e.latlng.lat, e.latlng.lng);
        });
      } else {
        for (const mk of markers) {
          const color = mk.favorite ? '#B5482C' : mk.wantToReturn ? '#B0812C' : '#3F5D75';
          const marker = L.marker([mk.geo.lat, mk.geo.lng], { icon: dot(color) }).addTo(map);
          marker.bindPopup(
            `<div style="font-family:system-ui;min-width:180px">
               <div style="font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#8a8172">${mk.neighborhoodName}</div>
               <div style="font-weight:700;font-size:15px;margin:2px 0 4px">${mk.name}</div>
               <div style="font-size:12px;color:#5c554a;margin-bottom:6px">${mk.explorations} ${mk.explorations === 1 ? 'exploração' : 'explorações'} · ${mk.free ? 'grátis' : 'pago'}</div>
               <a href="/lugares/${mk.slug}" style="font-size:12px;font-weight:700;color:#2A1E13;border-bottom:2px solid #B0812C">Abrir lugar →</a>
             </div>`,
          );
        }
        if (markers.length > 1) {
          const b = L.latLngBounds(markers.map((m) => [m.geo.lat, m.geo.lng] as [number, number]));
          map.fitBounds(b.pad(0.2), { maxZoom: 14 });
        }
      }
    })();

    return () => {
      disposed = true;
      const m = mapRef.current as { remove?: () => void } | null;
      if (m && typeof m.remove === 'function') m.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <div ref={ref} className="sp-map" style={{ height, width: '100%' }} aria-label="Mapa de São Paulo" />;
}
