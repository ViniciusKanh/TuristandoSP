/**
 * Cadastra lugares direto no SEU banco (Turso, ou arquivo local se não houver conexão).
 * Lê as credenciais de .data/connection.json (salvas pelo painel) ou das variáveis
 * de ambiente. Idempotente: se o slug já existe, pula. Rode com:
 *
 *   npm run seed:places
 */
import { createClient } from '@libsql/client';
import { readFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, '..', '.data');

function slugify(input) {
  return input
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function connection() {
  if (process.env.TURSO_DATABASE_URL) {
    return { url: process.env.TURSO_DATABASE_URL, authToken: process.env.TURSO_AUTH_TOKEN };
  }
  // conexão do painel (nova) ou config antiga (legado) — ambas guardam tursoUrl/tursoToken
  for (const file of ['connection.json', 'config.json']) {
    try {
      const c = JSON.parse(readFileSync(join(dataDir, file), 'utf8'));
      if (c.tursoUrl) return { url: c.tursoUrl, authToken: c.tursoToken };
    } catch {}
  }
  try { mkdirSync(dataDir, { recursive: true }); } catch {}
  return { url: `file:${join(dataDir, 'local.db')}` };
}

const now = new Date().toISOString();

// name, short, hood (nome do bairro), region, lat, lng, cats[], station{name,type,min}, free, priceMax, minutes, tags[]
const SPECS = [
  { name: 'Museu do Ipiranga', short: 'O Museu Paulista, no Parque da Independência — palácio, jardins à francesa e a memória da independência.', hood: 'Ipiranga', region: 'zona-sul', lat: -23.58516, lng: -46.60918, cats: ['museus', 'historia', 'arquitetura'], station: { name: 'Alto do Ipiranga', type: 'metro', min: 20 }, free: false, priceMax: 30, minutes: 150, tags: ['historia', 'independencia', 'jardins'] },
  { name: 'Museu de Zoologia da USP', short: 'Um dos maiores acervos zoológicos da América Latina, na divisa do Ipiranga com a Água Funda.', hood: 'Ipiranga', region: 'zona-sul', lat: -23.58937, lng: -46.61639, cats: ['museus', 'historia'], station: { name: 'Alto do Ipiranga', type: 'metro', min: 15 }, free: false, priceMax: 10, minutes: 120, tags: ['ciencia', 'familia'] },
  { name: 'Museu Histórico da Imigração Japonesa', short: 'A história da imigração japonesa no Brasil, no coração da Liberdade.', hood: 'Liberdade', region: 'centro', lat: -23.55779, lng: -46.63447, cats: ['museus', 'cultura', 'historia'], station: { name: 'São Joaquim', type: 'metro', min: 6 }, free: false, priceMax: 15, minutes: 120, tags: ['liberdade', 'cultura-japonesa', 'perto-do-metro'] },
  { name: 'Parque Santo Dias', short: 'Área verde, quadras e lazer no Campo Limpo, zona sul.', hood: 'Campo Limpo', region: 'zona-sul', lat: -23.64328, lng: -46.75722, cats: ['parques', 'passeios-gratuitos'], station: { name: 'Campo Limpo', type: 'metro', min: 22 }, free: true, priceMax: 0, minutes: 90, tags: ['gratis', 'ao-ar-livre'] },
  { name: 'Igreja Matriz de Santo Amaro', short: 'A tradicional matriz no Largo Treze, marco histórico de Santo Amaro.', hood: 'Santo Amaro', region: 'zona-sul', lat: -23.65243, lng: -46.70849, cats: ['historia', 'arquitetura'], station: { name: 'Largo Treze', type: 'metro', min: 4 }, free: true, priceMax: 0, minutes: 45, tags: ['historia', 'perto-do-metro'] },
  { name: 'Casa das Rosas', short: 'Casarão histórico na Avenida Paulista, espaço de poesia e literatura, com jardim.', hood: 'Paulista', region: 'centro', lat: -23.57206, lng: -46.64110, cats: ['cultura', 'historia', 'arquitetura'], station: { name: 'Brigadeiro', type: 'metro', min: 3 }, free: true, priceMax: 0, minutes: 75, tags: ['gratis', 'paulista', 'literatura', 'perto-do-metro'] },
  { name: 'Rua Oscar Freire', short: 'A rua mais famosa dos Jardins — arquitetura, vitrines e cafés.', hood: 'Oscar Freire', region: 'zona-oeste', lat: -23.56289, lng: -46.66936, cats: ['lugares-curiosos', 'arquitetura', 'cafes'], station: { name: 'Oscar Freire', type: 'metro', min: 2 }, free: true, priceMax: 0, minutes: 90, tags: ['compras', 'jardins', 'perto-do-metro'] },
  { name: 'Edifício Copan', short: 'A onda de Niemeyer na República — um dos edifícios mais icônicos de São Paulo.', hood: 'República', region: 'centro', lat: -23.54622, lng: -46.64365, cats: ['arquitetura', 'historia'], station: { name: 'República', type: 'metro', min: 5 }, free: true, priceMax: 0, minutes: 40, tags: ['niemeyer', 'centro', 'arquitetura', 'perto-do-metro'] },
];

function buildPlace(s) {
  const slug = slugify(s.name);
  return {
    id: `p-${slug}`,
    slug,
    name: s.name,
    shortDescription: s.short,
    description: s.short,
    address: { street: '', zip: '' },
    neighborhood: slugify(s.hood),
    neighborhoodName: s.hood,
    region: s.region,
    geo: { lat: s.lat, lng: s.lng },
    nearestStations: [{ type: s.station.type, name: s.station.name, walkingMinutes: s.station.min }],
    categories: s.cats,
    tags: s.tags,
    price: { min: 0, max: s.free ? 0 : s.priceMax, free: s.free },
    hours: undefined,
    accessibility: { wheelchair: false },
    status: 'ativo',
    coverImage: { id: `img-${slug}`, url: '', demo: true, width: 1600, height: 1067, alt: s.name, order: 0 },
    favorite: false,
    wantToReturn: false,
    rating: 4,
    recommendedMinutes: s.minutes,
    createdAt: now,
    updatedAt: now,
  };
}

const DDL = `CREATE TABLE IF NOT EXISTS places (
  slug TEXT PRIMARY KEY, name TEXT NOT NULL, short_desc TEXT NOT NULL DEFAULT '',
  neighborhood TEXT NOT NULL, region TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL,
  is_free INTEGER NOT NULL DEFAULT 0, price_max REAL NOT NULL DEFAULT 0,
  favorite INTEGER NOT NULL DEFAULT 0, want_to_return INTEGER NOT NULL DEFAULT 0,
  recommended_minutes INTEGER, status TEXT NOT NULL DEFAULT 'ativo',
  categories TEXT NOT NULL DEFAULT '[]', data TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
)`;

async function main() {
  const conn = connection();
  const db = createClient(conn.authToken ? { url: conn.url, authToken: conn.authToken } : { url: conn.url });
  const onTurso = conn.url.startsWith('libsql') || conn.url.startsWith('http');
  console.log(`Banco: ${onTurso ? 'Turso (' + conn.url + ')' : 'arquivo local'}`);
  await db.execute(DDL);

  let added = 0, skipped = 0;
  for (const spec of SPECS) {
    const p = buildPlace(spec);
    const exists = await db.execute({ sql: 'SELECT 1 FROM places WHERE slug = ?', args: [p.slug] });
    if (exists.rows.length) { console.log(`= já existe: ${p.name} (${p.slug})`); skipped++; continue; }
    await db.execute({
      sql: `INSERT INTO places (slug,name,short_desc,neighborhood,region,lat,lng,is_free,price_max,favorite,want_to_return,recommended_minutes,status,categories,data,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      args: [p.slug, p.name, p.shortDescription, p.neighborhood, p.region, p.geo.lat, p.geo.lng, p.price.free ? 1 : 0, p.price.max, 0, 0, p.recommendedMinutes, p.status, JSON.stringify(p.categories), JSON.stringify(p), p.createdAt, p.updatedAt],
    });
    console.log(`+ cadastrado: ${p.name} — bairro ${p.neighborhoodName} — ${p.geo.lat},${p.geo.lng} — ★4`);
    added++;
  }
  console.log(`\nPronto: ${added} cadastrados, ${skipped} já existiam.`);
}

main().catch((e) => { console.error('Falha:', e.message); process.exit(1); });
